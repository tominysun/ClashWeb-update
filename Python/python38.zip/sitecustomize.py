import os
import sys
import glob
import _imp
import builtins

py_dir = os.path.dirname(sys.executable)

def pkgdll_get_path(loader, path, name):
    dll_name = name.split('.')[-1] + dll_tag_ext
    dll_path = os.path.join(os.path.dirname(path), dll_name)
    if 'zipimporter object' in str(loader):
        path = os.path.join(eggs_cache,
                            os.path.basename(loader.archive) + '-tmp',
                            loader.prefix,
                            dll_name)
        if not os.path.exists(path):
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, 'wb') as f:
                f.write(loader.get_data(dll_path))
    else:
        path = dll_path
    return path

def set_prefix():
    for name in ('PYTHONPATH', 'PYTHONHOME', 'PYTHONUSERBASE'):
        os.environ.pop(name, None)
    sys.prefix = py_dir
    sys.base_prefix = py_dir
    sys.exec_prefix = py_dir
    sys.base_exec_prefix = py_dir
    import site
    site.PREFIXES[:] = [py_dir]
    site.USER_SITE = None
    site.USER_BASE = None

def set_path():
    global eggs_cache
    if 'VIRTUAL_ENV' in os.environ:
        home = os.environ['PYTHONHOME']
        prompt = os.environ.get('VIRTUAL_PROMPT')
        dlls = os.path.join(home, 'DLLs')
        for i, path in enumerate(sys.path):
            if path == dlls:
                sys.path[i] = os.path.join(py_dir, 'DLLs')
            elif path.endswith('site-packages'):
                if os.path.exists(path):
                    sys.path[i + 1:i + 1] = glob.glob(os.path.join(path, '*.egg'))
                    break
        eggs_cache = os.path.join(home, 'Eggs-Cache')
        if prompt:
            sys.ps1 = prompt + ' >>> '
            sys.ps2 = ' ' * len(prompt) + ' ... '
    else:
        if not (py_dir == sys.prefix == sys.base_prefix == sys.exec_prefix == sys.base_exec_prefix):
            set_prefix()
        sp_dir = os.path.join(py_dir, 'site-packages')
        sys.path[:] = [os.path.join(py_dir, 'python%d%d.zip' % sys.version_info[:2])]
        sys.path.append(os.path.join(py_dir, 'DLLs'))
        sys.path.append(py_dir)
        if os.path.exists(sp_dir):
            sys.path.append(sp_dir)
            sys.path.extend(glob.glob(os.path.join(sp_dir, '*.egg')))
        eggs_cache = os.path.join(py_dir, 'Eggs-Cache')

def main():
    global dll_tag_ext
    for dll_ext in _imp.extension_suffixes():
        if dll_ext[:3] == '.cp':
            dll_tag_ext = dll_ext
            break
    builtins.pkgdll_get_path = pkgdll_get_path
    set_path()

main()
