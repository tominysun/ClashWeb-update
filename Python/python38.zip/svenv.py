"""
A simple virtual environment script for Python.
Additional files must be copied manually, if need.
It's only targeted at Windows platform.
"""

import os
import sys

help = """Creates a simple virtual environment for Python

Use:  python -m svenv venvdir [prompt]

  venvdir       A directory to create the environment in.
  prompt        Provides an alternative prompt prefix for this environment.
                If not set, will use the directory name.

"""

activate_bat = """@echo off
set VIRTUAL_ENV=%~dp0
set VIRTUAL_PROMPT={prompt}
set PYTHONNOUSERSITE=
set PYTHONHOME=%VIRTUAL_ENV%
set _PYTHON_PROJECT_BASE=%VIRTUAL_ENV%
set PATH=%VIRTUAL_ENV%Scripts;{exe_dir};%VIRTUAL_ENV%;%PATH%
if not defined PROMPT set PROMPT=$P$G
set PROMPT=({prompt}) %PROMPT%
echo on
"""

launcher_bat = """@if not defined VIRTUAL_ENV call "%~dp0activate.bat"
@"{exe}" %*
"""

console_bat = """@if not defined VIRTUAL_ENV (
    call "%~dp0activate.bat"
    cmd
)
"""

def create(env_dir, prompt):
    lib_dir = os.path.join(env_dir, 'Lib')
    sp_dir = os.path.join(env_dir, lib_dir, 'site-packages')
    exe_dir = os.path.dirname(sys.executable)
    os.makedirs(sp_dir, exist_ok=True)
    with open(os.path.join(env_dir, 'activate.bat'), 'w') as f:
        f.write(activate_bat.format(prompt=prompt, exe_dir=exe_dir))
    with open(os.path.join(env_dir, 'python.bat'), 'w') as f:
        f.write(launcher_bat.format(exe=sys.executable))
    with open(os.path.join(env_dir, 'console.bat'), 'w') as f:
        f.write(console_bat)
    print('New virtual environment created at %r, prompt is %r.' % (env_dir, prompt))

def main():
    try:
        env_dir = sys.argv[1]
    except IndexError:
        print(help)
        return
    if not os.path.isabs(env_dir) or os.path.isfile(env_dir):
        raise ValueError("The environment path must be absolute, and can't be a exists file.")
    try:
        prompt = sys.argv[2]
    except IndexError:
        prompt = os.path.basename(env_dir.rstrip(os.path.sep))
    create(env_dir, prompt)

if __name__ == '__main__':
    rc = 1
    try:
        main()
        rc = 0
    except Exception as e:
        print('Error: %s' % e, file=sys.stderr)
    sys.exit(rc)
